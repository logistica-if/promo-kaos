# Promo KAOS · Sistema Egreso Técnica 2026 — Guía de instalación y uso

Flujo: **Cupo → Registro nominal → Pago → Confirmación → QR → Mesa → Check-in**.
La base de datos (Supabase) es la única fuente válida: nadie ingresa si no figura como CONFIRMADO.

## Archivos

| Archivo | Para qué |
|---|---|
| `index.html` | La aplicación completa (admin, egresados, acreditación, entradas) |
| `config.js` | Dirección y clave de tu proyecto Supabase + nombre de la promo y lema (lo único que hay que editar) |
| `lib/` | Librerías de QR, Excel, lector de cámara y tipografías de la promo (todo incluido: no depende de servicios externos, carga rápido con señal móvil) |
| `supabase/schema.sql` | Base de datos: tablas, reglas y controles |

---

## 1. Crear la base de datos (Supabase, gratis) — 10 minutos

1. Entrá a <https://supabase.com> → **Start your project** → registrate (podés usar tu cuenta de Google o GitHub).
2. **New project**: nombre `egreso-tecnica-2026`, contraseña de base (guardala), región **São Paulo** (la más cercana). Dejá activado *Data API*.
3. Esperá 1–2 minutos a que se cree.
4. Menú izquierdo → **SQL Editor** → **New query** → pegá TODO el contenido de `supabase/schema.sql` → **Run**. Tiene que decir *Success*.
5. Menú → **Project Settings → API** (o *Data API* / *API Keys*). Copiá:
   - **Project URL** (ej. `https://abcd1234.supabase.co`)
   - **anon public** key (o *publishable key*)
6. Abrí `config.js` y pegá esos dos valores.

> La clave *anon* es pública por diseño. Las tablas están cerradas: la web solo puede usar funciones que validan sesión, rol, aforo, DNI y QR.

## 2. Publicar la web (GitHub Pages)

1. En GitHub: **New repository** → `egreso-2026` (puede ser público; no contiene datos, solo el programa).
2. **Add file → Upload files** → subí `index.html`, `config.js` y la carpeta `lib/` completa → *Commit*.
3. **Settings → Pages** → Source: *Deploy from a branch* → `main` / `root` → Save.
4. En 1–2 minutos queda en `https://TU-USUARIO.github.io/egreso-2026/`.

## 3. Primera configuración

1. Abrí la web → **Crear primer administrador** (usuario + PIN de 6 números). Solo aparece la primera vez.
2. **Configuración**: revisá capacidad (800), menú activo y precios, horas de reserva, cupo de pulseras del brindis, precio del brindis (base 15.000 + adicional), **datos para pagar** (alias/CBU/link de Mercado Pago) y *Otros lugares reservados*.
3. **Usuarios**: creá los otros organizadores (rol *Administrador*) y los 2 de la puerta (rol *Acreditador*: solo ven la pantalla de ingreso).
4. **Egresados → Carga en lote**: pegá desde Excel `Apellido; Nombre; DNI; Cupo`. Se generan los códigos E01…E34 y un PIN para cada uno. **Descargá el Excel de accesos** (los PIN no se vuelven a mostrar; se pueden regenerar).
5. **Egresados → PD (Profesores / Directivos)** → *± Cupo* para reservarles lugares, y *Abrir* para cargarlos con nombre.
6. **Mesas → Crear varias** (ej. 1 a 40, capacidad 30).

Mandale a cada egresado su link + código + PIN (botón *Enviar por WhatsApp*).

## 4. Cómo funciona

**Cupos y aforo.** Cada egresado ocupa 1 lugar propio + su cupo de invitados. La **bolsa general** = capacidad − egresados − cupos asignados − reservas − pulseras (si están tildadas como parte del aforo). La base rechaza cualquier operación que la deje negativa: es imposible sobrevender, aunque dos personas carguen al mismo tiempo.
Liberar lugares → vuelven a la bolsa. Solicitar lugares → un admin aprueba y asigna desde la bolsa.

**Invitados.** DNI único en todo el evento (cena + brindis). Categoría automática por edad (configurable: 0–2 / 3–12 / adulto). Los de 0–2 años y el propio egresado quedan confirmados sin cargo, pero ocupan lugar.

**Pagos.** El egresado *informa* un pago (medio + n° de operación) → un admin lo *acredita* en **Pagos** → el invitado queda PAGADO y se emite la entrada (CONFIRMADO). El admin también puede registrar pagos en efectivo/transferencia directamente. Lo pagado conserva el precio aunque después cambie el menú.
Reservas pendientes vencidas (sin pago informado) → botón **Liberar vencidas** en Resumen.

**Entradas.** Numeración `E01-001`. El QR es único (código aleatorio) y sirve una sola vez. Se descargan como imagen o se comparten por WhatsApp; el link también muestra la entrada.

**Acreditación.** Desde el celular: login con usuario de acreditador → escanear QR o buscar por apellido, nombre, DNI o n° de entrada → **REGISTRAR INGRESO**. Un QR usado muestra pantalla roja **ENTRADA YA UTILIZADA** con la hora. Pestaña *Brindis*: buscar por n° de pulsera (B-001), apellido o DNI; solo entra si tiene pulsera asignada **y** pago registrado.

## 5. Día del evento — checklist

- [ ] La noche anterior: **Configuración → Backup completo** y **Exportar → Todo en un solo Excel**.
- [ ] Imprimir **Lista impresa para la entrada** y **Lista impresa brindis** (respaldo sin señal).
- [ ] Enviar al Club la **Lista para Club Sarmiento** y el **Reporte por mesa** (restricciones por mesa).
- [ ] En cada celular de la puerta: ingresar, tocar **Actualizar lista offline**, probar la cámara con una entrada.
- [ ] Si se corta la señal: la búsqueda sigue funcionando con la lista guardada, pero el ingreso **no se registra** hasta que vuelva la conexión (así se evita que un QR entre dos veces). Mientras tanto, usar la lista impresa y tildar.

## 6. Importante

- **Supabase gratis pausa el proyecto tras 7 días sin uso.** Mientras lo estén usando no pasa; si se pausa, se reactiva desde el panel de Supabase (los datos no se pierden).
- El plan gratis no incluye backups automáticos: usá el botón de backup semanalmente.
- Todo cambio relevante queda en **Configuración → Registro de cambios** (quién, qué y cuándo).
- Mercado Pago: en esta versión se muestra el alias/link y los pagos se acreditan a mano. La integración automática (checkout + webhook) queda preparada para una segunda etapa.

## Supuestos que tomé (se pueden cambiar en Configuración)

- 0–2 años = hasta 2 años inclusive; 3–12 = menor; 13+ = adulto.
- El egresado no paga su propia tarjeta (tilde *El egresado paga su propia tarjeta* si corresponde).
- Las pulseras del brindis cuentan dentro de las 800 personas (se puede destildar).
- Reserva de 72 h esperando el pago.
- Hora del evento 20:30 hs y menú activo **Carne** ($65.000 adulto / $50.000 menor / 0–2 sin cargo), como en el afiche.
