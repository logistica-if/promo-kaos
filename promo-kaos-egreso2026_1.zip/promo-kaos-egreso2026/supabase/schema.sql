-- =====================================================================
--  SISTEMA EGRESO TÉCNICA 2026 — Base de datos (Supabase / PostgreSQL)
--  Pegar COMPLETO en Supabase > SQL Editor > New query > Run.
--  Se puede volver a ejecutar: NO borra datos existentes.
--
--  Principio de seguridad: ninguna tabla es accesible directamente desde
--  la web. Todo pasa por funciones (RPC) que validan sesión, rol, aforo,
--  DNI único y QR de un solo uso. La base es la única fuente válida.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------
-- TABLAS
-- ---------------------------------------------------------------------
create table if not exists config (
  id                      int primary key default 1 check (id = 1),
  evento                  text not null default 'Egreso Escuela Técnica 2026',
  fecha                   date not null default '2026-11-21',
  hora                    text not null default '20:30',
  lugar                   text not null default 'Club Sarmiento',
  capacidad               int  not null default 800 check (capacidad > 0),
  reserva_otros           int  not null default 0 check (reserva_otros >= 0),
  cupo_brindis            int  not null default 0 check (cupo_brindis >= 0),
  brindis_suma_aforo      boolean not null default true,
  menu_activo             text not null default 'Carne',
  edad_max_bebe           int  not null default 2,
  edad_max_menor          int  not null default 12,
  horas_reserva           int  not null default 72 check (horas_reserva >= 0),
  egresado_paga_tarjeta   boolean not null default false,
  precio_brindis_base     int  not null default 15000,
  precio_brindis_adicional int not null default 0,
  brindis_max_por_egresado int not null default 0,   -- 0 = sin límite
  cupo_inicial_default    int  not null default 20,
  datos_pago              text not null default ''    -- alias / CBU / link de Mercado Pago
);
insert into config (id) values (1) on conflict do nothing;

create table if not exists precios (
  menu      text not null,
  categoria text not null check (categoria in ('adulto','menor','bebe')),
  precio    int  not null check (precio >= 0),
  primary key (menu, categoria)
);
insert into precios values
  ('Pollo','adulto',55000),('Pollo','menor',40000),('Pollo','bebe',0),
  ('Carne','adulto',65000),('Carne','menor',50000),('Carne','bebe',0)
on conflict do nothing;

-- Responsables de cupo: los 34 egresados + grupos institucionales (PD = profesores/directivos)
create table if not exists responsables (
  id            serial primary key,
  codigo        text unique not null,
  tipo          text not null check (tipo in ('egresado','institucional')),
  nombre        text not null,
  apellido      text not null default '',
  cupo_inicial  int not null default 0 check (cupo_inicial >= 0),
  cupo_extra    int not null default 0 check (cupo_extra >= 0),
  cupo_liberado int not null default 0 check (cupo_liberado >= 0),
  pin_hash      text,
  activo        boolean not null default true,
  creado        timestamptz not null default now(),
  check (cupo_inicial + cupo_extra - cupo_liberado >= 0)
);
insert into responsables (codigo, tipo, nombre, apellido)
values ('PD','institucional','Profesores / Directivos','')
on conflict do nothing;

create table if not exists usuarios (
  id       serial primary key,
  usuario  text unique not null,
  nombre   text not null,
  rol      text not null check (rol in ('admin','acreditador')),
  pin_hash text not null,
  activo   boolean not null default true,
  creado   timestamptz not null default now()
);

create table if not exists sesiones (
  token          uuid primary key default gen_random_uuid(),
  rol            text not null,
  usuario_id     int,
  responsable_id int,
  actor          text not null,
  creado         timestamptz not null default now(),
  expira         timestamptz not null default now() + interval '14 days'
);

create table if not exists login_intentos (
  id      bigserial primary key,
  usuario text not null,
  fecha   timestamptz not null default now()
);

create table if not exists mesas (
  id             serial primary key,
  numero         int unique not null,
  nombre         text not null default '',
  tipo           text not null default 'Familia',
  capacidad      int,                       -- null = sin tope
  responsable_id int references responsables(id),
  notas          text not null default ''
);

create table if not exists invitados (
  id                  serial primary key,
  responsable_id      int not null references responsables(id),
  nro                 int not null,
  codigo              text unique not null,
  es_egresado         boolean not null default false,
  nombre              text not null,
  apellido            text not null,
  dni                 text not null,
  edad                int  not null check (edad between 0 and 120),
  vinculo             text not null default 'Familia',
  restriccion         text not null default 'Sin restricción'
                      check (restriccion in ('Sin restricción','Celíaco','Vegetariano','Hipertenso','Otra')),
  restriccion_detalle text not null default '',
  observaciones       text not null default '',
  mesa_id             int references mesas(id) on delete set null,
  estado              text not null default 'pendiente'
                      check (estado in ('pendiente','pagado','confirmado','cancelado')),
  precio_final        int,
  vence_en            timestamptz,
  qr                  text unique,
  ingreso_at          timestamptz,
  ingreso_por         text,
  creado              timestamptz not null default now(),
  actualizado         timestamptz not null default now(),
  cancelado_at        timestamptz,
  unique (responsable_id, nro)
);
create unique index if not exists invitados_dni_activo on invitados (dni) where estado <> 'cancelado';

create table if not exists pagos (
  id          serial primary key,
  invitado_id int not null references invitados(id),
  monto       int not null check (monto > 0),
  medio       text not null default 'Transferencia',
  referencia  text not null default '',
  estado      text not null default 'acreditado' check (estado in ('informado','acreditado','rechazado')),
  creado      timestamptz not null default now(),
  informado_por text,
  registrado_por text
);

create table if not exists solicitudes (
  id                serial primary key,
  responsable_id    int not null references responsables(id),
  cantidad          int not null check (cantidad > 0),
  motivo            text not null default '',
  estado            text not null default 'pendiente' check (estado in ('pendiente','aprobada','rechazada')),
  cantidad_aprobada int not null default 0,
  respuesta         text not null default '',
  creado            timestamptz not null default now(),
  resuelto_at       timestamptz,
  resuelto_por      text
);

create table if not exists brindis (
  id             serial primary key,
  pulsera        int unique,
  responsable_id int not null references responsables(id),
  nombre         text not null,
  apellido       text not null,
  dni            text not null,
  observaciones  text not null default '',
  pagado         boolean not null default false,
  monto          int not null default 0,
  medio          text not null default '',
  pagado_at      timestamptz,
  estado         text not null default 'activo' check (estado in ('activo','cancelado')),
  ingreso_at     timestamptz,
  ingreso_por    text,
  creado         timestamptz not null default now()
);
create unique index if not exists brindis_dni_activo on brindis (dni) where estado = 'activo';

create table if not exists auditoria (
  id      bigserial primary key,
  fecha   timestamptz not null default now(),
  actor   text not null,
  accion  text not null,
  detalle jsonb
);

-- Nada de acceso directo a tablas desde la web
alter table config         enable row level security;
alter table precios        enable row level security;
alter table responsables   enable row level security;
alter table usuarios       enable row level security;
alter table sesiones       enable row level security;
alter table login_intentos enable row level security;
alter table mesas          enable row level security;
alter table invitados      enable row level security;
alter table pagos          enable row level security;
alter table solicitudes    enable row level security;
alter table brindis        enable row level security;
alter table auditoria      enable row level security;
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

-- ---------------------------------------------------------------------
-- FUNCIONES INTERNAS
-- ---------------------------------------------------------------------
create or replace function _cfg() returns config
language sql stable set search_path = public as $$ select * from config where id = 1 $$;

create or replace function _log(p_actor text, p_accion text, p_detalle jsonb default null) returns void
language sql set search_path = public as $$
  insert into auditoria (actor, accion, detalle) values (p_actor, p_accion, p_detalle)
$$;

create or replace function _sesion(p_token uuid) returns sesiones
language plpgsql set search_path = public as $$
declare s sesiones;
begin
  select * into s from sesiones where token = p_token and expira > now();
  if not found then raise exception 'SESION: Tu sesión venció. Ingresá nuevamente.'; end if;
  -- si el usuario/egresado fue dado de baja, la sesión deja de valer
  if s.usuario_id is not null and not exists (select 1 from usuarios where id = s.usuario_id and activo) then
    raise exception 'SESION: Usuario desactivado.';
  end if;
  if s.rol = 'egresado' and not exists (select 1 from responsables where id = s.responsable_id and activo) then
    raise exception 'SESION: Usuario desactivado.';
  end if;
  return s;
end $$;

create or replace function _req(p_token uuid, p_roles text[]) returns sesiones
language plpgsql set search_path = public as $$
declare s sesiones;
begin
  s := _sesion(p_token);
  if not (s.rol = any(p_roles)) then raise exception 'No tenés permiso para esta acción.'; end if;
  return s;
end $$;

create or replace function _nuevo_pin() returns text
language sql volatile set search_path = public, extensions as $$
  select lpad(((('x' || encode(gen_random_bytes(4), 'hex'))::bit(32)::bigint) % 1000000)::text, 6, '0')
$$;

create or replace function _hash(p_pin text) returns text
language sql volatile set search_path = public, extensions as $$ select crypt(p_pin, gen_salt('bf', 8)) $$;

create or replace function _check_pin(p_pin text, p_hash text) returns boolean
language sql stable set search_path = public, extensions as $$ select p_hash is not null and crypt(p_pin, p_hash) = p_hash $$;

create or replace function _dni(p text) returns text
language plpgsql immutable as $$
declare d text := upper(regexp_replace(coalesce(p,''), '[^0-9A-Za-z]', '', 'g'));
begin
  if length(d) < 6 or length(d) > 12 then raise exception 'DNI inválido: "%"', p; end if;
  return d;
end $$;

create or replace function _categoria(p_edad int) returns text
language sql stable set search_path = public as $$
  select case when p_edad <= c.edad_max_bebe then 'bebe'
              when p_edad <= c.edad_max_menor then 'menor'
              else 'adulto' end from config c where id = 1
$$;

create or replace function _precio(i invitados) returns int
language sql stable set search_path = public as $$
  select case
    when i.precio_final is not null then i.precio_final
    when i.es_egresado and not c.egresado_paga_tarjeta then 0
    else coalesce((select p.precio from precios p where p.menu = c.menu_activo and p.categoria = _categoria(i.edad)), 0)
  end from config c where c.id = 1
$$;

create or replace function _pagado(p_inv int) returns int
language sql stable set search_path = public as $$
  select coalesce(sum(monto),0)::int from pagos where invitado_id = p_inv and estado = 'acreditado'
$$;

create or replace function _cupo(r responsables) returns int
language sql immutable as $$ select r.cupo_inicial + r.cupo_extra - r.cupo_liberado $$;

create or replace function _usados(p_resp int) returns int
language sql stable set search_path = public as $$
  select count(*)::int from invitados where responsable_id = p_resp and not es_egresado and estado <> 'cancelado'
$$;

-- Bolsa general = capacidad - egresados - cupos asignados - reservas - brindis
create or replace function _bolsa() returns int
language sql stable set search_path = public as $$
  select c.capacidad
       - (select count(*) from responsables where tipo = 'egresado' and activo)
       - (select coalesce(sum(_cupo(r)),0) from responsables r where activo)
       - c.reserva_otros
       - case when c.brindis_suma_aforo then c.cupo_brindis else 0 end
  from config c where c.id = 1
$$;

create or replace function _lock() returns void
language sql as $$ select pg_advisory_xact_lock(20261121) $$;

create or replace function _check_aforo() returns void
language plpgsql set search_path = public as $$
declare b int := _bolsa();
begin
  if b < 0 then
    raise exception 'AFORO: La operación supera la capacidad máxima del salón (faltan % lugares).', -b;
  end if;
end $$;

create or replace function _dni_libre(p_dni text, p_excl_inv int, p_excl_brindis int) returns void
language plpgsql set search_path = public as $$
declare x record;
begin
  select i.codigo, i.nombre, i.apellido into x from invitados i
   where i.dni = p_dni and i.estado <> 'cancelado' and i.id is distinct from p_excl_inv limit 1;
  if found then raise exception 'DNI %: ya está registrado (% % – %).', p_dni, x.nombre, x.apellido, x.codigo; end if;
  select b.nombre, b.apellido into x from brindis b
   where b.dni = p_dni and b.estado = 'activo' and b.id is distinct from p_excl_brindis limit 1;
  if found then raise exception 'DNI %: ya está registrado en el brindis (% %).', p_dni, x.nombre, x.apellido; end if;
end $$;

create or replace function _nuevo_qr() returns text
language sql volatile set search_path = public, extensions as $$ select encode(gen_random_bytes(16), 'hex') $$;

-- Pasa de pendiente → pagado cuando lo acreditado cubre el precio; confirma si corresponde
create or replace function _recalcular(p_inv int, p_confirmar boolean, p_actor text) returns void
language plpgsql set search_path = public as $$
declare i invitados; pr int; pg int;
begin
  select * into i from invitados where id = p_inv for update;
  if i.estado = 'cancelado' then return; end if;
  pr := _precio(i); pg := _pagado(p_inv);
  if i.estado = 'pendiente' and pg >= pr then
    update invitados set estado = 'pagado', precio_final = pr, vence_en = null, actualizado = now() where id = p_inv;
    i.estado := 'pagado';
  end if;
  if p_confirmar and i.estado = 'pagado' then
    update invitados set estado = 'confirmado', qr = coalesce(qr, _nuevo_qr()), actualizado = now() where id = p_inv;
    perform _log(p_actor, 'confirmar', jsonb_build_object('codigo', i.codigo));
  end if;
end $$;

-- Representación JSON de un invitado
create or replace function _inv_json(i invitados) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'id', i.id, 'codigo', i.codigo, 'responsable_id', i.responsable_id,
    'responsable', r.codigo, 'responsable_nombre', trim(r.nombre || ' ' || r.apellido),
    'es_egresado', i.es_egresado, 'nombre', i.nombre, 'apellido', i.apellido, 'dni', i.dni,
    'edad', i.edad, 'categoria', _categoria(i.edad), 'vinculo', i.vinculo,
    'restriccion', i.restriccion, 'restriccion_detalle', i.restriccion_detalle,
    'observaciones', i.observaciones, 'mesa_id', i.mesa_id, 'mesa', m.numero, 'mesa_nombre', m.nombre,
    'estado', i.estado, 'precio', _precio(i), 'pagado', _pagado(i.id),
    'informado', (select coalesce(sum(monto),0) from pagos where invitado_id = i.id and estado = 'informado'),
    'vence_en', i.vence_en, 'vencido', (i.estado = 'pendiente' and i.vence_en is not null and i.vence_en < now()),
    'qr', case when i.estado = 'confirmado' then i.qr end,
    'ingreso_at', i.ingreso_at, 'creado', i.creado)
  from responsables r left join mesas m on m.id = i.mesa_id where r.id = i.responsable_id
$$;

create or replace function _brindis_json(b brindis) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'id', b.id, 'pulsera', b.pulsera,
    'codigo', case when b.pulsera is null then null else 'B-' || lpad(b.pulsera::text, 3, '0') end,
    'responsable_id', b.responsable_id, 'responsable', r.codigo, 'responsable_nombre', trim(r.nombre || ' ' || r.apellido),
    'nombre', b.nombre, 'apellido', b.apellido, 'dni', b.dni, 'observaciones', b.observaciones,
    'pagado', b.pagado, 'monto', b.monto, 'medio', b.medio, 'estado', b.estado,
    'ingreso_at', b.ingreso_at, 'creado', b.creado)
  from responsables r where r.id = b.responsable_id
$$;

create or replace function _config_json() returns jsonb
language sql stable set search_path = public as $$
  select to_jsonb(c) || jsonb_build_object(
    'precios', (select jsonb_agg(jsonb_build_object('menu', menu, 'categoria', categoria, 'precio', precio) order by menu, categoria) from precios),
    'precio_brindis', c.precio_brindis_base + c.precio_brindis_adicional)
  from config c where id = 1
$$;

create or replace function _aforo() returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'capacidad', c.capacidad,
    'egresados', (select count(*) from responsables where tipo = 'egresado' and activo),
    'institucional', (select coalesce(sum(_cupo(r)),0) from responsables r where tipo = 'institucional' and activo),
    'reserva_otros', c.reserva_otros,
    'brindis_reservado', case when c.brindis_suma_aforo then c.cupo_brindis else 0 end,
    'asignado_egresados', (select coalesce(sum(_cupo(r)),0) from responsables r where tipo = 'egresado' and activo),
    'cargados', (select count(*) from invitados where estado <> 'cancelado' and not es_egresado),
    'cargados_institucional', (select count(*) from invitados i join responsables r on r.id = i.responsable_id where i.estado <> 'cancelado' and r.tipo = 'institucional'),
    'pendientes', (select count(*) from invitados where estado = 'pendiente'),
    'pagados', (select count(*) from invitados where estado = 'pagado'),
    'confirmados', (select count(*) from invitados where estado = 'confirmado'),
    'vencidos', (select count(*) from invitados where estado = 'pendiente' and vence_en < now()),
    'disponible', _bolsa(),
    'solicitudes_pendientes', (select count(*) from solicitudes where estado = 'pendiente'),
    'solicitudes_lugares', (select coalesce(sum(cantidad),0) from solicitudes where estado = 'pendiente'),
    'ingresados', (select count(*) from invitados where ingreso_at is not null))
  from config c where c.id = 1
$$;

-- ---------------------------------------------------------------------
-- API PÚBLICA (sin sesión)
-- ---------------------------------------------------------------------
create or replace function estado_inicial() returns jsonb
language sql security definer set search_path = public as $$
  select jsonb_build_object('hay_admin', exists(select 1 from usuarios where rol = 'admin' and activo),
    'evento', c.evento, 'fecha', c.fecha, 'hora', c.hora, 'lugar', c.lugar) from config c where id = 1
$$;

create or replace function crear_admin_inicial(p_usuario text, p_nombre text, p_pin text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform _lock();
  if exists (select 1 from usuarios where rol = 'admin') then raise exception 'Ya existe un administrador.'; end if;
  if p_pin !~ '^[0-9]{6,}$' then raise exception 'El PIN debe tener al menos 6 números.'; end if;
  insert into usuarios (usuario, nombre, rol, pin_hash) values (lower(trim(p_usuario)), trim(p_nombre), 'admin', _hash(p_pin));
  perform _log('sistema', 'crear_admin_inicial', jsonb_build_object('usuario', lower(trim(p_usuario))));
  return jsonb_build_object('ok', true);
end $$;

create or replace function login(p_usuario text, p_pin text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare u usuarios; r responsables; t uuid; k text := lower(trim(p_usuario));
begin
  if (select count(*) from login_intentos where usuario = k and fecha > now() - interval '15 minutes') >= 5 then
    return jsonb_build_object('ok', false, 'error', 'Demasiados intentos fallidos. Esperá 15 minutos.');
  end if;
  select * into u from usuarios where usuario = k and activo;
  if found and _check_pin(p_pin, u.pin_hash) then
    insert into sesiones (rol, usuario_id, actor) values (u.rol, u.id, u.rol || ':' || u.usuario) returning token into t;
    delete from login_intentos where usuario = k;
    return jsonb_build_object('ok', true, 'token', t, 'rol', u.rol, 'nombre', u.nombre);
  end if;
  select * into r from responsables where lower(codigo) = k and tipo = 'egresado' and activo;
  if found and _check_pin(p_pin, r.pin_hash) then
    insert into sesiones (rol, responsable_id, actor) values ('egresado', r.id, r.codigo) returning token into t;
    delete from login_intentos where usuario = k;
    return jsonb_build_object('ok', true, 'token', t, 'rol', 'egresado', 'nombre', trim(r.nombre || ' ' || r.apellido), 'codigo', r.codigo);
  end if;
  insert into login_intentos (usuario) values (k);
  return jsonb_build_object('ok', false, 'error', 'Usuario o PIN incorrecto.');
end $$;

create or replace function logout(p_token uuid) returns jsonb
language sql security definer set search_path = public as $$
  delete from sesiones where token = p_token; select jsonb_build_object('ok', true)
$$;

-- Entrada digital (acceso por el código QR, que actúa como la "tarjeta")
create or replace function ver_entrada(p_qr text) returns jsonb
language sql security definer set search_path = public as $$
  select jsonb_build_object('ok', true, 'nombre', i.nombre, 'apellido', i.apellido, 'codigo', i.codigo,
    'mesa', m.numero, 'mesa_nombre', m.nombre, 'categoria', _categoria(i.edad), 'qr', i.qr,
    'usada', i.ingreso_at is not null, 'ingreso_at', i.ingreso_at,
    'evento', c.evento, 'fecha', c.fecha, 'hora', c.hora, 'lugar', c.lugar)
  from invitados i left join mesas m on m.id = i.mesa_id, config c
  where i.qr = p_qr and i.estado = 'confirmado' and c.id = 1
$$;

-- ---------------------------------------------------------------------
-- EGRESADO (el admin también puede usarlas indicando responsable_id)
-- ---------------------------------------------------------------------
create or replace function _resp_de(s sesiones, p_resp int) returns int
language plpgsql as $$
begin
  if s.rol = 'egresado' then return s.responsable_id; end if;
  if s.rol = 'admin' then
    if p_resp is null then raise exception 'Falta indicar el egresado responsable.'; end if;
    return p_resp;
  end if;
  raise exception 'No tenés permiso para esta acción.';
end $$;

create or replace function mi_panel(p_token uuid, p_responsable_id int default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; rid int; r responsables;
begin
  s := _req(p_token, array['egresado','admin']);
  rid := _resp_de(s, p_responsable_id);
  select * into r from responsables where id = rid;
  return jsonb_build_object(
    'responsable', jsonb_build_object('id', r.id, 'codigo', r.codigo, 'tipo', r.tipo, 'nombre', r.nombre, 'apellido', r.apellido,
        'cupo_inicial', r.cupo_inicial, 'cupo_extra', r.cupo_extra, 'cupo_liberado', r.cupo_liberado, 'cupo', _cupo(r)),
    'usados', _usados(rid),
    'invitados', coalesce((select jsonb_agg(_inv_json(i) order by i.nro) from invitados i where i.responsable_id = rid), '[]'),
    'brindis', coalesce((select jsonb_agg(_brindis_json(b) order by b.id) from brindis b where b.responsable_id = rid), '[]'),
    'solicitudes', coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from solicitudes x where x.responsable_id = rid), '[]'),
    'pagos', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'codigo', i.codigo, 'nombre', i.nombre || ' ' || i.apellido,
        'monto', p.monto, 'medio', p.medio, 'referencia', p.referencia, 'estado', p.estado, 'creado', p.creado) order by p.id desc)
        from pagos p join invitados i on i.id = p.invitado_id where i.responsable_id = rid), '[]'),
    'config', _config_json(),
    'bolsa', case when s.rol = 'admin' then _bolsa() end);
end $$;

create or replace function guardar_invitado(p_token uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; rid int; i invitados; v_id int := nullif(p_data->>'id','')::int; v_dni text; r responsables;
        v_nro int; c config; pr int; v_estado text;
begin
  s := _req(p_token, array['egresado','admin']);
  perform _lock();
  c := _cfg();
  v_dni := _dni(p_data->>'dni');
  if coalesce(trim(p_data->>'nombre'),'') = '' or coalesce(trim(p_data->>'apellido'),'') = '' then
    raise exception 'Nombre y apellido son obligatorios.';
  end if;
  if (p_data->>'edad') is null or (p_data->>'edad') !~ '^[0-9]{1,3}$' then raise exception 'Edad inválida.'; end if;

  if v_id is null then
    rid := _resp_de(s, nullif(p_data->>'responsable_id','')::int);
    select * into r from responsables where id = rid and activo;
    if not found then raise exception 'Responsable inexistente o dado de baja.'; end if;
    if _usados(rid) + 1 > _cupo(r) then
      raise exception 'CUPO: % no tiene lugares disponibles (cupo %, cargados %). Liberá o solicitá lugares adicionales.',
        r.codigo, _cupo(r), _usados(rid);
    end if;
    perform _dni_libre(v_dni, null, null);
    select coalesce(max(nro),0) + 1 into v_nro from invitados where responsable_id = rid;
    insert into invitados (responsable_id, nro, codigo, nombre, apellido, dni, edad, vinculo, restriccion,
                           restriccion_detalle, observaciones)
    values (rid, v_nro, r.codigo || '-' || lpad(v_nro::text, 3, '0'), trim(p_data->>'nombre'), trim(p_data->>'apellido'),
            v_dni, (p_data->>'edad')::int, coalesce(nullif(p_data->>'vinculo',''), 'Familia'),
            coalesce(nullif(p_data->>'restriccion',''), 'Sin restricción'), coalesce(p_data->>'restriccion_detalle',''),
            coalesce(p_data->>'observaciones',''))
    returning * into i;
    pr := _precio(i);
    if pr = 0 then
      update invitados set estado = 'confirmado', precio_final = 0, qr = _nuevo_qr() where id = i.id returning * into i;
    elsif c.horas_reserva > 0 then
      update invitados set vence_en = now() + make_interval(hours => c.horas_reserva) where id = i.id returning * into i;
    end if;
    perform _log(s.actor, 'alta_invitado', jsonb_build_object('codigo', i.codigo, 'dni', i.dni));
  else
    select * into i from invitados where id = v_id for update;
    if not found or i.estado = 'cancelado' then raise exception 'Invitado inexistente o cancelado.'; end if;
    if s.rol = 'egresado' and i.responsable_id <> s.responsable_id then raise exception 'No tenés permiso para esta acción.'; end if;
    if s.rol = 'egresado' and i.es_egresado and v_dni <> i.dni then raise exception 'Tu DNI solo lo puede cambiar un administrador.'; end if;
    perform _dni_libre(v_dni, i.id, null);
    -- si cambia la edad antes de pagar, el precio se recalcula solo; si ya pagó, el precio queda fijo
    update invitados set nombre = trim(p_data->>'nombre'), apellido = trim(p_data->>'apellido'), dni = v_dni,
        edad = (p_data->>'edad')::int, vinculo = coalesce(nullif(p_data->>'vinculo',''), vinculo),
        restriccion = coalesce(nullif(p_data->>'restriccion',''), restriccion),
        restriccion_detalle = coalesce(p_data->>'restriccion_detalle',''),
        observaciones = coalesce(p_data->>'observaciones',''), actualizado = now()
    where id = v_id returning * into i;
    if i.estado = 'pendiente' and _precio(i) = 0 then
      update invitados set estado = 'confirmado', precio_final = 0, vence_en = null, qr = _nuevo_qr() where id = i.id returning * into i;
    end if;
    perform _log(s.actor, 'editar_invitado', jsonb_build_object('codigo', i.codigo, 'datos', p_data));
  end if;
  return _inv_json(i);
end $$;

create or replace function cancelar_invitado(p_token uuid, p_id int, p_motivo text default '') returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; i invitados;
begin
  s := _req(p_token, array['egresado','admin']);
  perform _lock();
  select * into i from invitados where id = p_id for update;
  if not found or i.estado = 'cancelado' then raise exception 'Invitado inexistente o ya cancelado.'; end if;
  if i.es_egresado then raise exception 'El registro del propio egresado no se puede cancelar.'; end if;
  if s.rol = 'egresado' then
    if i.responsable_id <> s.responsable_id then raise exception 'No tenés permiso para esta acción.'; end if;
    if i.estado <> 'pendiente' or _pagado(i.id) > 0 then
      raise exception 'Este invitado ya tiene pagos o está confirmado: solo un administrador puede cancelarlo.';
    end if;
  end if;
  if i.ingreso_at is not null then raise exception 'Esta persona ya ingresó al evento.'; end if;
  update invitados set estado = 'cancelado', qr = null, mesa_id = null, cancelado_at = now(), actualizado = now() where id = p_id;
  update pagos set estado = 'rechazado' where invitado_id = p_id and estado = 'informado';
  perform _log(s.actor, 'cancelar_invitado', jsonb_build_object('codigo', i.codigo, 'dni', i.dni, 'estado_previo', i.estado,
      'pagado', _pagado(i.id), 'motivo', p_motivo));
  return jsonb_build_object('ok', true);
end $$;

-- El egresado devuelve lugares que no usa a la bolsa general
create or replace function liberar_lugares(p_token uuid, p_cantidad int, p_responsable_id int default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; rid int; r responsables;
begin
  s := _req(p_token, array['egresado','admin']);
  perform _lock();
  rid := _resp_de(s, p_responsable_id);
  select * into r from responsables where id = rid for update;
  if p_cantidad is null or p_cantidad <= 0 then raise exception 'Cantidad inválida.'; end if;
  if _cupo(r) - _usados(rid) < p_cantidad then
    raise exception 'Solo podés liberar lugares libres (tenés % sin usar).', _cupo(r) - _usados(rid);
  end if;
  update responsables set cupo_liberado = cupo_liberado + p_cantidad where id = rid;
  perform _log(s.actor, 'liberar_lugares', jsonb_build_object('responsable', r.codigo, 'cantidad', p_cantidad));
  return jsonb_build_object('ok', true, 'bolsa', _bolsa());
end $$;

create or replace function solicitar_lugares(p_token uuid, p_cantidad int, p_motivo text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['egresado']);
  if p_cantidad is null or p_cantidad <= 0 or p_cantidad > 200 then raise exception 'Cantidad inválida.'; end if;
  insert into solicitudes (responsable_id, cantidad, motivo) values (s.responsable_id, p_cantidad, coalesce(p_motivo,''));
  perform _log(s.actor, 'solicitar_lugares', jsonb_build_object('cantidad', p_cantidad, 'motivo', p_motivo));
  return jsonb_build_object('ok', true);
end $$;

create or replace function informar_pago(p_token uuid, p_invitado_id int, p_monto int, p_medio text, p_referencia text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; i invitados;
begin
  s := _req(p_token, array['egresado']);
  select * into i from invitados where id = p_invitado_id;
  if not found or i.responsable_id <> s.responsable_id or i.estado = 'cancelado' then raise exception 'Invitado inválido.'; end if;
  if i.estado <> 'pendiente' then raise exception 'Este invitado ya figura como pagado.'; end if;
  if coalesce(p_monto,0) <= 0 then raise exception 'Monto inválido.'; end if;
  insert into pagos (invitado_id, monto, medio, referencia, estado, informado_por)
  values (p_invitado_id, p_monto, coalesce(nullif(p_medio,''),'Transferencia'), coalesce(p_referencia,''), 'informado', s.actor);
  perform _log(s.actor, 'informar_pago', jsonb_build_object('codigo', i.codigo, 'monto', p_monto, 'referencia', p_referencia));
  return jsonb_build_object('ok', true);
end $$;

create or replace function guardar_brindis(p_token uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; rid int; b brindis; v_id int := nullif(p_data->>'id','')::int; v_dni text; c config;
        v_pul int := nullif(p_data->>'pulsera','')::int;
begin
  s := _req(p_token, array['egresado','admin']);
  perform _lock();
  c := _cfg();
  v_dni := _dni(p_data->>'dni');
  if coalesce(trim(p_data->>'nombre'),'') = '' or coalesce(trim(p_data->>'apellido'),'') = '' then
    raise exception 'Nombre y apellido son obligatorios.';
  end if;
  if v_id is null then
    rid := _resp_de(s, nullif(p_data->>'responsable_id','')::int);
    if (select count(*) from brindis where estado = 'activo') + 1 > c.cupo_brindis then
      raise exception 'BRINDIS: No quedan pulseras disponibles (cupo total %).', c.cupo_brindis;
    end if;
    if c.brindis_max_por_egresado > 0 and s.rol = 'egresado'
       and (select count(*) from brindis where estado = 'activo' and responsable_id = rid) + 1 > c.brindis_max_por_egresado then
      raise exception 'BRINDIS: Máximo % invitados al brindis por egresado.', c.brindis_max_por_egresado;
    end if;
    perform _dni_libre(v_dni, null, null);
    insert into brindis (responsable_id, nombre, apellido, dni, observaciones)
    values (rid, trim(p_data->>'nombre'), trim(p_data->>'apellido'), v_dni, coalesce(p_data->>'observaciones',''))
    returning * into b;
    perform _log(s.actor, 'alta_brindis', jsonb_build_object('id', b.id, 'dni', v_dni));
  else
    select * into b from brindis where id = v_id for update;
    if not found or b.estado <> 'activo' then raise exception 'Registro de brindis inexistente o cancelado.'; end if;
    if s.rol = 'egresado' and b.responsable_id <> s.responsable_id then raise exception 'No tenés permiso para esta acción.'; end if;
    perform _dni_libre(v_dni, null, b.id);
    update brindis set nombre = trim(p_data->>'nombre'), apellido = trim(p_data->>'apellido'), dni = v_dni,
        observaciones = coalesce(p_data->>'observaciones','') where id = v_id returning * into b;
    perform _log(s.actor, 'editar_brindis', jsonb_build_object('id', b.id, 'datos', p_data));
  end if;
  -- solo el admin asigna número de pulsera
  if s.rol = 'admin' and p_data ? 'pulsera' then
    if v_pul is not null and exists (select 1 from brindis where pulsera = v_pul and id <> b.id) then
      raise exception 'La pulsera B-% ya está asignada a otra persona.', lpad(v_pul::text,3,'0');
    end if;
    update brindis set pulsera = v_pul where id = b.id returning * into b;
  end if;
  return _brindis_json(b);
end $$;

create or replace function cancelar_brindis(p_token uuid, p_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; b brindis;
begin
  s := _req(p_token, array['egresado','admin']);
  select * into b from brindis where id = p_id for update;
  if not found or b.estado <> 'activo' then raise exception 'Registro inexistente.'; end if;
  if s.rol = 'egresado' and (b.responsable_id <> s.responsable_id or b.pagado) then
    raise exception 'Solo un administrador puede cancelar un registro pagado.';
  end if;
  if b.ingreso_at is not null then raise exception 'Esta persona ya ingresó.'; end if;
  update brindis set estado = 'cancelado', pulsera = null where id = p_id;
  perform _log(s.actor, 'cancelar_brindis', jsonb_build_object('id', b.id, 'dni', b.dni, 'pulsera', b.pulsera));
  return jsonb_build_object('ok', true);
end $$;

-- ---------------------------------------------------------------------
-- ADMINISTRADOR
-- ---------------------------------------------------------------------
create or replace function dashboard(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  return jsonb_build_object(
    'aforo', _aforo(),
    'config', _config_json(),
    'pagos', (select jsonb_build_object(
        'esperado', coalesce(sum(_precio(i)) filter (where i.estado <> 'cancelado'),0),
        'cobrado', (select coalesce(sum(monto),0) from pagos where estado = 'acreditado'),
        'informado', (select coalesce(sum(monto),0) from pagos where estado = 'informado'),
        'informados_cant', (select count(*) from pagos where estado = 'informado'),
        'tarjetas_pagadas', count(*) filter (where i.estado in ('pagado','confirmado') and _precio(i) > 0),
        'tarjetas_sin_cargo', count(*) filter (where i.estado <> 'cancelado' and _precio(i) = 0))
      from invitados i),
    'alimentacion', (select coalesce(jsonb_object_agg(restriccion, n), '{}') from
        (select restriccion, count(*) n from invitados where estado <> 'cancelado' group by restriccion) x),
    'categorias', (select coalesce(jsonb_object_agg(cat, n), '{}') from
        (select _categoria(edad) cat, count(*) n from invitados where estado <> 'cancelado' group by 1) x),
    'responsables', (select coalesce(jsonb_agg(jsonb_build_object(
        'id', r.id, 'codigo', r.codigo, 'tipo', r.tipo, 'nombre', r.nombre, 'apellido', r.apellido, 'activo', r.activo,
        'cupo_inicial', r.cupo_inicial, 'cupo_extra', r.cupo_extra, 'cupo_liberado', r.cupo_liberado, 'cupo', _cupo(r),
        'usados', _usados(r.id), 'tiene_pin', r.pin_hash is not null,
        'extras_solicitados', (select coalesce(sum(cantidad),0) from solicitudes where responsable_id = r.id),
        'pagados', (select count(*) from invitados i where i.responsable_id = r.id and i.estado in ('pagado','confirmado') and not i.es_egresado),
        'pendientes', (select count(*) from invitados i where i.responsable_id = r.id and i.estado = 'pendiente'),
        'confirmados', (select count(*) from invitados i where i.responsable_id = r.id and i.estado = 'confirmado'),
        'esperado', (select coalesce(sum(_precio(i)),0) from invitados i where i.responsable_id = r.id and i.estado <> 'cancelado'),
        'cobrado', (select coalesce(sum(p.monto),0) from pagos p join invitados i on i.id = p.invitado_id where i.responsable_id = r.id and p.estado = 'acreditado'),
        'brindis', (select count(*) from brindis b where b.responsable_id = r.id and b.estado = 'activo'),
        'brindis_cobrado', (select coalesce(sum(monto),0) from brindis b where b.responsable_id = r.id and b.estado = 'activo' and b.pagado)
      ) order by r.tipo, r.codigo), '[]') from responsables r),
    'brindis', (select jsonb_build_object(
        'cupo', (select cupo_brindis from config),
        'registrados', count(*) filter (where estado = 'activo'),
        'asignadas', count(*) filter (where estado = 'activo' and pulsera is not null),
        'pagadas', count(*) filter (where estado = 'activo' and pagado),
        'ingresadas', count(*) filter (where estado = 'activo' and ingreso_at is not null),
        'cobrado', coalesce(sum(monto) filter (where estado = 'activo' and pagado),0)) from brindis),
    'mesas', (select coalesce(jsonb_agg(jsonb_build_object('id', m.id, 'numero', m.numero, 'nombre', m.nombre, 'tipo', m.tipo,
        'capacidad', m.capacidad, 'responsable_id', m.responsable_id, 'notas', m.notas,
        'ocupados', (select count(*) from invitados i where i.mesa_id = m.id and i.estado <> 'cancelado')) order by m.numero), '[]') from mesas m)
  );
end $$;

create or replace function listar_invitados(p_token uuid, p_incluir_cancelados boolean default false) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  return coalesce((select jsonb_agg(_inv_json(i) order by i.responsable_id, i.nro) from invitados i
                   where p_incluir_cancelados or i.estado <> 'cancelado'), '[]');
end $$;

create or replace function listar_brindis(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  return coalesce((select jsonb_agg(_brindis_json(b) order by b.pulsera nulls last, b.id) from brindis b where b.estado = 'activo'), '[]');
end $$;

create or replace function listar_pagos(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'invitado_id', i.id, 'codigo', i.codigo,
      'nombre', i.nombre || ' ' || i.apellido, 'responsable', r.codigo, 'monto', p.monto, 'medio', p.medio,
      'referencia', p.referencia, 'estado', p.estado, 'creado', p.creado, 'informado_por', p.informado_por,
      'registrado_por', p.registrado_por, 'precio', _precio(i), 'estado_invitado', i.estado) order by p.id desc)
    from pagos p join invitados i on i.id = p.invitado_id join responsables r on r.id = i.responsable_id), '[]');
end $$;

-- Alta/edición de egresados y grupos institucionales
create or replace function guardar_responsable(p_token uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; r responsables; v_id int := nullif(p_data->>'id','')::int; v_pin text; v_cod text; n int;
        v_tipo text := coalesce(nullif(p_data->>'tipo',''), 'egresado'); v_dni text; v_nro_cupo int; inv invitados;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  if coalesce(trim(p_data->>'nombre'),'') = '' then raise exception 'El nombre es obligatorio.'; end if;
  v_nro_cupo := coalesce(nullif(p_data->>'cupo_inicial','')::int, (_cfg()).cupo_inicial_default);
  if v_id is null then
    v_cod := upper(nullif(trim(p_data->>'codigo'),''));
    if v_cod is null then
      if v_tipo = 'egresado' then
        select coalesce(max(substring(codigo from 2)::int),0) + 1 into n from responsables where codigo ~ '^E[0-9]+$';
        v_cod := 'E' || lpad(n::text, 2, '0');
      else raise exception 'Indicá un código para el grupo (ej. PD, STAFF).'; end if;
    end if;
    if v_cod !~ '^[A-Z0-9]{1,6}$' then raise exception 'Código inválido (solo letras/números, máx. 6).'; end if;
    if v_tipo = 'egresado' then
      v_dni := _dni(p_data->>'dni');
      perform _dni_libre(v_dni, null, null);
      v_pin := _nuevo_pin();
    end if;
    insert into responsables (codigo, tipo, nombre, apellido, cupo_inicial, pin_hash)
    values (v_cod, v_tipo, trim(p_data->>'nombre'), coalesce(trim(p_data->>'apellido'),''), v_nro_cupo,
            case when v_pin is null then null else _hash(v_pin) end)
    returning * into r;
    if v_tipo = 'egresado' then
      insert into invitados (responsable_id, nro, codigo, es_egresado, nombre, apellido, dni, edad, vinculo, restriccion, restriccion_detalle)
      values (r.id, 0, r.codigo || '-000', true, r.nombre, r.apellido, v_dni, coalesce(nullif(p_data->>'edad','')::int, 18), 'Egresado',
              coalesce(nullif(p_data->>'restriccion',''),'Sin restricción'), coalesce(p_data->>'restriccion_detalle',''))
      returning * into inv;
      if _precio(inv) = 0 then
        update invitados set estado = 'confirmado', precio_final = 0, qr = _nuevo_qr() where id = inv.id;
      end if;
    end if;
    perform _check_aforo();
    perform _log(s.actor, 'alta_responsable', jsonb_build_object('codigo', r.codigo, 'tipo', v_tipo, 'cupo', v_nro_cupo));
  else
    select * into r from responsables where id = v_id for update;
    if not found then raise exception 'Responsable inexistente.'; end if;
    if r.cupo_extra + v_nro_cupo - r.cupo_liberado < _usados(r.id) then
      raise exception 'CUPO: % ya tiene % invitados cargados; el cupo no puede quedar por debajo.', r.codigo, _usados(r.id);
    end if;
    if r.cupo_extra + v_nro_cupo - r.cupo_liberado < 0 then
      raise exception 'CUPO: el cupo resultante no puede ser negativo (tiene % liberados).', r.cupo_liberado;
    end if;
    update responsables set nombre = trim(p_data->>'nombre'), apellido = coalesce(trim(p_data->>'apellido'),''),
        cupo_inicial = v_nro_cupo where id = v_id returning * into r;
    if r.tipo = 'egresado' then
      update invitados set nombre = r.nombre, apellido = r.apellido, actualizado = now() where responsable_id = r.id and es_egresado;
    end if;
    perform _check_aforo();
    perform _log(s.actor, 'editar_responsable', jsonb_build_object('codigo', r.codigo, 'datos', p_data));
  end if;
  return jsonb_build_object('ok', true, 'id', r.id, 'codigo', r.codigo, 'pin', v_pin);
end $$;

create or replace function reset_pin(p_token uuid, p_responsable_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; v_pin text := _nuevo_pin(); r responsables;
begin
  s := _req(p_token, array['admin']);
  update responsables set pin_hash = _hash(v_pin) where id = p_responsable_id and tipo = 'egresado' returning * into r;
  if not found then raise exception 'Egresado inexistente.'; end if;
  delete from sesiones where responsable_id = r.id;
  perform _log(s.actor, 'reset_pin', jsonb_build_object('codigo', r.codigo));
  return jsonb_build_object('ok', true, 'codigo', r.codigo, 'pin', v_pin);
end $$;

-- Asignar lugares extra (positivo) o quitar lugares (negativo) a un responsable
create or replace function ajustar_cupo(p_token uuid, p_responsable_id int, p_delta int, p_motivo text default '') returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; r responsables;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  select * into r from responsables where id = p_responsable_id for update;
  if not found then raise exception 'Responsable inexistente.'; end if;
  if p_delta = 0 then raise exception 'Cantidad inválida.'; end if;
  if p_delta > 0 then
    update responsables set cupo_extra = cupo_extra + p_delta where id = r.id;
  else
    if _cupo(r) + p_delta < _usados(r.id) then
      raise exception 'CUPO: % tiene % lugares usados; no se pueden quitar %.', r.codigo, _usados(r.id), -p_delta;
    end if;
    update responsables set cupo_liberado = cupo_liberado - p_delta where id = r.id;
  end if;
  perform _check_aforo();
  perform _log(s.actor, 'ajustar_cupo', jsonb_build_object('codigo', r.codigo, 'delta', p_delta, 'motivo', p_motivo));
  return jsonb_build_object('ok', true, 'bolsa', _bolsa());
end $$;

create or replace function baja_responsable(p_token uuid, p_responsable_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; r responsables;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  select * into r from responsables where id = p_responsable_id for update;
  if exists (select 1 from invitados where responsable_id = r.id and estado in ('pagado','confirmado') and not es_egresado) then
    raise exception 'Tiene invitados pagados/confirmados: cancelalos primero.';
  end if;
  update invitados set estado = 'cancelado', qr = null, cancelado_at = now() where responsable_id = r.id and estado <> 'cancelado';
  update responsables set activo = false, cupo_liberado = cupo_inicial + cupo_extra where id = r.id;
  delete from sesiones where responsable_id = r.id;
  perform _log(s.actor, 'baja_responsable', jsonb_build_object('codigo', r.codigo));
  return jsonb_build_object('ok', true);
end $$;

create or replace function listar_solicitudes(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  return coalesce((select jsonb_agg(to_jsonb(x) || jsonb_build_object('codigo', r.codigo, 'responsable_nombre', trim(r.nombre||' '||r.apellido))
         order by (x.estado = 'pendiente') desc, x.id desc) from solicitudes x join responsables r on r.id = x.responsable_id), '[]');
end $$;

create or replace function resolver_solicitud(p_token uuid, p_id int, p_aprobar boolean, p_cantidad int, p_respuesta text default '') returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; x solicitudes;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  select * into x from solicitudes where id = p_id for update;
  if not found or x.estado <> 'pendiente' then raise exception 'La solicitud ya fue resuelta.'; end if;
  if p_aprobar then
    if coalesce(p_cantidad,0) <= 0 then raise exception 'Cantidad inválida.'; end if;
    if p_cantidad > _bolsa() then raise exception 'AFORO: Solo quedan % lugares en la bolsa general.', _bolsa(); end if;
    update responsables set cupo_extra = cupo_extra + p_cantidad where id = x.responsable_id;
    perform _check_aforo();
  end if;
  update solicitudes set estado = case when p_aprobar then 'aprobada' else 'rechazada' end,
      cantidad_aprobada = case when p_aprobar then p_cantidad else 0 end, respuesta = coalesce(p_respuesta,''),
      resuelto_at = now(), resuelto_por = s.actor where id = p_id;
  perform _log(s.actor, 'resolver_solicitud', jsonb_build_object('id', p_id, 'aprobada', p_aprobar, 'cantidad', p_cantidad));
  return jsonb_build_object('ok', true, 'bolsa', _bolsa());
end $$;

create or replace function guardar_config(p_token uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; antes jsonb; p jsonb;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  antes := _config_json();
  update config set
    evento = coalesce(p_data->>'evento', evento), fecha = coalesce((p_data->>'fecha')::date, fecha),
    hora = coalesce(p_data->>'hora', hora), lugar = coalesce(p_data->>'lugar', lugar),
    capacidad = coalesce((p_data->>'capacidad')::int, capacidad),
    reserva_otros = coalesce((p_data->>'reserva_otros')::int, reserva_otros),
    cupo_brindis = coalesce((p_data->>'cupo_brindis')::int, cupo_brindis),
    brindis_suma_aforo = coalesce((p_data->>'brindis_suma_aforo')::boolean, brindis_suma_aforo),
    menu_activo = coalesce(p_data->>'menu_activo', menu_activo),
    edad_max_bebe = coalesce((p_data->>'edad_max_bebe')::int, edad_max_bebe),
    edad_max_menor = coalesce((p_data->>'edad_max_menor')::int, edad_max_menor),
    horas_reserva = coalesce((p_data->>'horas_reserva')::int, horas_reserva),
    egresado_paga_tarjeta = coalesce((p_data->>'egresado_paga_tarjeta')::boolean, egresado_paga_tarjeta),
    precio_brindis_base = coalesce((p_data->>'precio_brindis_base')::int, precio_brindis_base),
    precio_brindis_adicional = coalesce((p_data->>'precio_brindis_adicional')::int, precio_brindis_adicional),
    brindis_max_por_egresado = coalesce((p_data->>'brindis_max_por_egresado')::int, brindis_max_por_egresado),
    cupo_inicial_default = coalesce((p_data->>'cupo_inicial_default')::int, cupo_inicial_default),
    datos_pago = coalesce(p_data->>'datos_pago', datos_pago)
  where id = 1;
  if p_data ? 'precios' then
    for p in select * from jsonb_array_elements(p_data->'precios') loop
      insert into precios (menu, categoria, precio) values (trim(p->>'menu'), p->>'categoria', (p->>'precio')::int)
      on conflict (menu, categoria) do update set precio = excluded.precio;
    end loop;
  end if;
  if not exists (select 1 from precios where menu = (select menu_activo from config)) then
    raise exception 'El menú activo no tiene precios cargados.';
  end if;
  if (select cupo_brindis from config) < (select count(*) from brindis where estado = 'activo') then
    raise exception 'Ya hay más invitados al brindis registrados que el cupo indicado.';
  end if;
  perform _check_aforo();
  perform _log(s.actor, 'guardar_config', jsonb_build_object('antes', antes, 'despues', _config_json()));
  return _config_json();
end $$;

create or replace function registrar_pago(p_token uuid, p_invitado_id int, p_monto int, p_medio text, p_referencia text, p_confirmar boolean default true) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; i invitados;
begin
  s := _req(p_token, array['admin']);
  select * into i from invitados where id = p_invitado_id for update;
  if not found or i.estado = 'cancelado' then raise exception 'Invitado inexistente o cancelado.'; end if;
  if coalesce(p_monto,0) <= 0 then raise exception 'Monto inválido.'; end if;
  insert into pagos (invitado_id, monto, medio, referencia, estado, registrado_por)
  values (i.id, p_monto, coalesce(nullif(p_medio,''),'Efectivo'), coalesce(p_referencia,''), 'acreditado', s.actor);
  perform _recalcular(i.id, p_confirmar, s.actor);
  perform _log(s.actor, 'registrar_pago', jsonb_build_object('codigo', i.codigo, 'monto', p_monto, 'medio', p_medio, 'ref', p_referencia));
  select * into i from invitados where id = p_invitado_id;
  return _inv_json(i);
end $$;

create or replace function verificar_pago(p_token uuid, p_pago_id int, p_aceptar boolean, p_confirmar boolean default true) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; p pagos;
begin
  s := _req(p_token, array['admin']);
  select * into p from pagos where id = p_pago_id for update;
  if not found or p.estado <> 'informado' then raise exception 'El pago ya fue procesado.'; end if;
  update pagos set estado = case when p_aceptar then 'acreditado' else 'rechazado' end, registrado_por = s.actor where id = p.id;
  if p_aceptar then perform _recalcular(p.invitado_id, p_confirmar, s.actor); end if;
  perform _log(s.actor, 'verificar_pago', jsonb_build_object('pago', p.id, 'aceptado', p_aceptar, 'monto', p.monto));
  return jsonb_build_object('ok', true);
end $$;

create or replace function anular_pago(p_token uuid, p_pago_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; p pagos; i invitados;
begin
  s := _req(p_token, array['admin']);
  select * into p from pagos where id = p_pago_id for update;
  if not found or p.estado <> 'acreditado' then raise exception 'Pago inexistente o no acreditado.'; end if;
  select * into i from invitados where id = p.invitado_id for update;
  if i.ingreso_at is not null then raise exception 'La persona ya ingresó.'; end if;
  update pagos set estado = 'rechazado' where id = p.id;
  if i.estado in ('pagado','confirmado') and _pagado(i.id) < coalesce(i.precio_final,0) then
    update invitados set estado = 'pendiente', qr = null, precio_final = null, actualizado = now() where id = i.id;
  end if;
  perform _log(s.actor, 'anular_pago', jsonb_build_object('pago', p.id, 'codigo', i.codigo, 'monto', p.monto));
  return jsonb_build_object('ok', true);
end $$;

create or replace function confirmar_invitados(p_token uuid, p_ids int[]) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; n int := 0; v int; i invitados;
begin
  s := _req(p_token, array['admin']);
  foreach v in array p_ids loop
    select * into i from invitados where id = v for update;
    if i.estado = 'pagado' or (i.estado = 'pendiente' and _pagado(i.id) >= _precio(i)) then
      perform _recalcular(i.id, true, s.actor);
      n := n + 1;
    end if;
  end loop;
  return jsonb_build_object('ok', true, 'confirmados', n);
end $$;

-- Libera las reservas pendientes vencidas (sin pago informado)
create or replace function liberar_vencidos(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; n int; cods jsonb;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  with x as (
    update invitados i set estado = 'cancelado', qr = null, mesa_id = null, cancelado_at = now(), actualizado = now()
    where i.estado = 'pendiente' and i.vence_en < now() and not i.es_egresado
      and not exists (select 1 from pagos p where p.invitado_id = i.id and p.estado in ('informado','acreditado'))
    returning i.codigo)
  select count(*), coalesce(jsonb_agg(codigo), '[]') into n, cods from x;
  perform _log(s.actor, 'liberar_vencidos', jsonb_build_object('cantidad', n, 'codigos', cods));
  return jsonb_build_object('ok', true, 'liberados', n);
end $$;

create or replace function asignar_mesa(p_token uuid, p_ids int[], p_mesa_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; m mesas; ocup int;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  if p_mesa_id is not null then
    select * into m from mesas where id = p_mesa_id;
    if not found then raise exception 'Mesa inexistente.'; end if;
    select count(*) into ocup from invitados where mesa_id = m.id and estado <> 'cancelado' and not (id = any(p_ids));
    if m.capacidad is not null and ocup + array_length(p_ids,1) > m.capacidad then
      raise exception 'La mesa % tiene capacidad % (ya ocupados %, intentás sumar %).', m.numero, m.capacidad, ocup, array_length(p_ids,1);
    end if;
  end if;
  update invitados set mesa_id = p_mesa_id, actualizado = now() where id = any(p_ids) and estado <> 'cancelado';
  perform _log(s.actor, 'asignar_mesa', jsonb_build_object('mesa', m.numero, 'invitados', p_ids));
  return jsonb_build_object('ok', true);
end $$;

create or replace function guardar_mesa(p_token uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; v_id int := nullif(p_data->>'id','')::int; m mesas;
begin
  s := _req(p_token, array['admin']);
  if v_id is null then
    insert into mesas (numero, nombre, tipo, capacidad, responsable_id, notas)
    values ((p_data->>'numero')::int, coalesce(p_data->>'nombre',''), coalesce(nullif(p_data->>'tipo',''),'Familia'),
            nullif(p_data->>'capacidad','')::int, nullif(p_data->>'responsable_id','')::int, coalesce(p_data->>'notas',''))
    returning * into m;
  else
    update mesas set numero = (p_data->>'numero')::int, nombre = coalesce(p_data->>'nombre',''),
        tipo = coalesce(nullif(p_data->>'tipo',''),'Familia'), capacidad = nullif(p_data->>'capacidad','')::int,
        responsable_id = nullif(p_data->>'responsable_id','')::int, notas = coalesce(p_data->>'notas','')
    where id = v_id returning * into m;
  end if;
  perform _log(s.actor, 'guardar_mesa', to_jsonb(m));
  return to_jsonb(m);
end $$;

create or replace function eliminar_mesa(p_token uuid, p_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  if exists (select 1 from invitados where mesa_id = p_id and estado <> 'cancelado') then
    raise exception 'La mesa tiene invitados asignados. Reasignalos primero.';
  end if;
  update invitados set mesa_id = null where mesa_id = p_id;
  delete from mesas where id = p_id;
  perform _log(s.actor, 'eliminar_mesa', jsonb_build_object('id', p_id));
  return jsonb_build_object('ok', true);
end $$;

create or replace function registrar_pago_brindis(p_token uuid, p_id int, p_pagado boolean, p_monto int, p_medio text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; b brindis;
begin
  s := _req(p_token, array['admin']);
  update brindis set pagado = p_pagado, monto = case when p_pagado then coalesce(p_monto,0) else 0 end,
      medio = case when p_pagado then coalesce(p_medio,'') else '' end, pagado_at = case when p_pagado then now() end
  where id = p_id and estado = 'activo' returning * into b;
  if not found then raise exception 'Registro inexistente.'; end if;
  perform _log(s.actor, 'pago_brindis', jsonb_build_object('id', b.id, 'pagado', p_pagado, 'monto', p_monto));
  return _brindis_json(b);
end $$;

create or replace function asignar_pulseras_auto(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; b record; nxt int; n int := 0;
begin
  s := _req(p_token, array['admin']);
  perform _lock();
  for b in select id from brindis where estado = 'activo' and pulsera is null order by responsable_id, id loop
    select coalesce(min(g), 1) into nxt from generate_series(1, 10000) g where not exists (select 1 from brindis where pulsera = g);
    update brindis set pulsera = nxt where id = b.id;
    n := n + 1;
  end loop;
  perform _log(s.actor, 'asignar_pulseras_auto', jsonb_build_object('cantidad', n));
  return jsonb_build_object('ok', true, 'asignadas', n);
end $$;

create or replace function listar_usuarios(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', id, 'usuario', usuario, 'nombre', nombre, 'rol', rol, 'activo', activo) order by rol, usuario) from usuarios), '[]');
end $$;

create or replace function guardar_usuario(p_token uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; v_id int := nullif(p_data->>'id','')::int; v_pin text := nullif(p_data->>'pin','');
begin
  s := _req(p_token, array['admin']);
  if v_pin is not null and v_pin !~ '^[0-9]{6,}$' then raise exception 'El PIN debe tener al menos 6 números.'; end if;
  if v_id is null then
    if v_pin is null then raise exception 'Indicá un PIN.'; end if;
    if lower(trim(p_data->>'usuario')) ~ '^e[0-9]+$' then raise exception 'Ese nombre de usuario está reservado para egresados.'; end if;
    insert into usuarios (usuario, nombre, rol, pin_hash)
    values (lower(trim(p_data->>'usuario')), trim(p_data->>'nombre'), p_data->>'rol', _hash(v_pin));
  else
    if v_id = s.usuario_id and not coalesce((p_data->>'activo')::boolean, true) then raise exception 'No podés desactivarte a vos mismo.'; end if;
    update usuarios set nombre = coalesce(trim(p_data->>'nombre'), nombre), rol = coalesce(p_data->>'rol', rol),
        activo = coalesce((p_data->>'activo')::boolean, activo),
        pin_hash = case when v_pin is null then pin_hash else _hash(v_pin) end where id = v_id;
    if v_pin is not null or not coalesce((p_data->>'activo')::boolean, true) then delete from sesiones where usuario_id = v_id and token <> p_token; end if;
  end if;
  perform _log(s.actor, 'guardar_usuario', p_data - 'pin');
  return jsonb_build_object('ok', true);
end $$;

create or replace function ver_auditoria(p_token uuid, p_limite int default 300) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  return coalesce((select jsonb_agg(to_jsonb(a) order by a.id desc) from (select * from auditoria order by id desc limit p_limite) a), '[]');
end $$;

create or replace function backup_completo(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin']);
  perform _log(s.actor, 'backup', null);
  return jsonb_build_object(
    'generado', now(),
    'config', (select to_jsonb(c) from config c),
    'precios', (select jsonb_agg(to_jsonb(p)) from precios p),
    'responsables', (select jsonb_agg(to_jsonb(r) - 'pin_hash') from responsables r),
    'usuarios', (select jsonb_agg(to_jsonb(u) - 'pin_hash') from usuarios u),
    'mesas', (select jsonb_agg(to_jsonb(m)) from mesas m),
    'invitados', (select jsonb_agg(to_jsonb(i)) from invitados i),
    'pagos', (select jsonb_agg(to_jsonb(p)) from pagos p),
    'solicitudes', (select jsonb_agg(to_jsonb(x)) from solicitudes x),
    'brindis', (select jsonb_agg(to_jsonb(b)) from brindis b),
    'auditoria', (select jsonb_agg(to_jsonb(a)) from auditoria a));
end $$;

-- ---------------------------------------------------------------------
-- ACREDITACIÓN (acreditador y admin)
-- ---------------------------------------------------------------------
create or replace function checkin_buscar(p_token uuid, p_q text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; q text := trim(coalesce(p_q,'')); qd text; res jsonb;
begin
  s := _req(p_token, array['admin','acreditador']);
  if length(q) < 2 then return '[]'; end if;
  -- QR escaneado (puede venir como URL ...#e=TOKEN)
  if q ~ 'e=[0-9a-f]{32}' then q := substring(q from 'e=([0-9a-f]{32})'); end if;
  qd := upper(regexp_replace(q, '[^0-9A-Za-z]', '', 'g'));
  select coalesce(jsonb_agg(x.j), '[]') into res from (
    select _inv_json(i) || jsonb_build_object('tipo', 'cena') j
    from invitados i
    where i.estado <> 'cancelado' and (
          i.qr = lower(q) or upper(i.codigo) = upper(q) or i.dni = qd
       or unaccent_simple(i.apellido || ' ' || i.nombre) ilike '%' || unaccent_simple(q) || '%'
       or unaccent_simple(i.nombre || ' ' || i.apellido) ilike '%' || unaccent_simple(q) || '%')
    order by (i.qr = lower(q)) desc, i.apellido, i.nombre limit 25) x;
  return res;
end $$;

create or replace function unaccent_simple(t text) returns text
language sql immutable as $$
  select lower(translate(coalesce(t,''), 'ÁÉÍÓÚÜÑáéíóúüñ', 'AEIOUUNaeiouun'))
$$;

create or replace function checkin_registrar(p_token uuid, p_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; i invitados;
begin
  s := _req(p_token, array['admin','acreditador']);
  select * into i from invitados where id = p_id for update;
  if not found or i.estado = 'cancelado' then
    return jsonb_build_object('ok', false, 'motivo', 'NO_REGISTRADO', 'mensaje', 'ENTRADA INVÁLIDA / CANCELADA');
  end if;
  if i.ingreso_at is not null then
    return jsonb_build_object('ok', false, 'motivo', 'YA_UTILIZADA', 'mensaje', 'ENTRADA YA UTILIZADA',
                              'ingreso_at', i.ingreso_at, 'ingreso_por', i.ingreso_por, 'invitado', _inv_json(i));
  end if;
  if i.estado <> 'confirmado' then
    return jsonb_build_object('ok', false, 'motivo', 'NO_CONFIRMADA', 'mensaje', 'NO CONFIRMADA (' || upper(i.estado) || ')', 'invitado', _inv_json(i));
  end if;
  update invitados set ingreso_at = now(), ingreso_por = s.actor where id = p_id returning * into i;
  perform _log(s.actor, 'checkin', jsonb_build_object('codigo', i.codigo));
  return jsonb_build_object('ok', true, 'mensaje', 'INGRESO REGISTRADO', 'invitado', _inv_json(i));
end $$;

create or replace function checkin_deshacer(p_token uuid, p_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; i invitados;
begin
  s := _req(p_token, array['admin']);
  update invitados set ingreso_at = null, ingreso_por = null where id = p_id returning * into i;
  perform _log(s.actor, 'checkin_deshacer', jsonb_build_object('codigo', i.codigo));
  return jsonb_build_object('ok', true);
end $$;

create or replace function brindis_buscar(p_token uuid, p_q text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; q text := trim(coalesce(p_q,'')); qd text; qn int;
begin
  s := _req(p_token, array['admin','acreditador']);
  if length(q) < 1 then return '[]'; end if;
  qd := upper(regexp_replace(q, '[^0-9A-Za-z]', '', 'g'));
  qn := nullif(regexp_replace(q, '[^0-9]', '', 'g'), '')::bigint % 1000000;
  return coalesce((select jsonb_agg(_brindis_json(b) order by b.pulsera) from (
    select * from brindis b where b.estado = 'activo' and (
         (q ~* '^b-?[0-9]+$' and b.pulsera = qn) or (q ~ '^[0-9]{1,4}$' and b.pulsera = qn) or b.dni = qd
      or unaccent_simple(b.apellido || ' ' || b.nombre) ilike '%' || unaccent_simple(q) || '%'
      or unaccent_simple(b.nombre || ' ' || b.apellido) ilike '%' || unaccent_simple(q) || '%')
    limit 25) b), '[]');
end $$;

create or replace function brindis_registrar(p_token uuid, p_id int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones; b brindis;
begin
  s := _req(p_token, array['admin','acreditador']);
  select * into b from brindis where id = p_id for update;
  if not found or b.estado <> 'activo' then return jsonb_build_object('ok', false, 'mensaje', 'NO REGISTRADO EN EL SISTEMA'); end if;
  if b.ingreso_at is not null then
    return jsonb_build_object('ok', false, 'mensaje', 'YA INGRESÓ', 'ingreso_at', b.ingreso_at, 'registro', _brindis_json(b));
  end if;
  if b.pulsera is null then return jsonb_build_object('ok', false, 'mensaje', 'SIN PULSERA ASIGNADA', 'registro', _brindis_json(b)); end if;
  if not b.pagado then return jsonb_build_object('ok', false, 'mensaje', 'NO PAGADO', 'registro', _brindis_json(b)); end if;
  update brindis set ingreso_at = now(), ingreso_por = s.actor where id = p_id returning * into b;
  perform _log(s.actor, 'checkin_brindis', jsonb_build_object('pulsera', b.pulsera));
  return jsonb_build_object('ok', true, 'mensaje', 'INGRESO REGISTRADO', 'registro', _brindis_json(b));
end $$;

-- Lista compacta para acreditación (caché del celular y lista impresa de respaldo)
create or replace function checkin_lista(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sesiones;
begin
  s := _req(p_token, array['admin','acreditador']);
  return jsonb_build_object(
    'cena', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'c', i.codigo, 'n', i.nombre, 'a', i.apellido, 'd', i.dni,
        'm', m.numero, 'r', case when i.restriccion = 'Otra' then 'Otra: ' || i.restriccion_detalle else i.restriccion end,
        'cat', _categoria(i.edad), 'e', i.estado, 'in', i.ingreso_at, 'r_cod', r.codigo) order by i.apellido, i.nombre)
      from invitados i join responsables r on r.id = i.responsable_id left join mesas m on m.id = i.mesa_id
      where i.estado <> 'cancelado'), '[]'),
    'brindis', coalesce((select jsonb_agg(_brindis_json(b) order by b.apellido) from brindis b where b.estado = 'activo'), '[]'),
    'stats', jsonb_build_object(
      'confirmados', (select count(*) from invitados where estado = 'confirmado'),
      'ingresados', (select count(*) from invitados where ingreso_at is not null),
      'brindis_habilitados', (select count(*) from brindis where estado = 'activo' and pagado and pulsera is not null),
      'brindis_ingresados', (select count(*) from brindis where ingreso_at is not null)),
    'config', (select jsonb_build_object('evento', evento, 'fecha', fecha, 'hora', hora, 'lugar', lugar, 'edad_max_bebe', edad_max_bebe, 'edad_max_menor', edad_max_menor) from config));
end $$;

-- ---------------------------------------------------------------------
-- PERMISOS: la web solo puede ejecutar estas funciones
-- ---------------------------------------------------------------------
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function
  estado_inicial(), crear_admin_inicial(text,text,text), login(text,text), logout(uuid), ver_entrada(text),
  mi_panel(uuid,int), guardar_invitado(uuid,jsonb), cancelar_invitado(uuid,int,text), liberar_lugares(uuid,int,int),
  solicitar_lugares(uuid,int,text), informar_pago(uuid,int,int,text,text), guardar_brindis(uuid,jsonb), cancelar_brindis(uuid,int),
  dashboard(uuid), listar_invitados(uuid,boolean), listar_brindis(uuid), listar_pagos(uuid), guardar_responsable(uuid,jsonb),
  reset_pin(uuid,int), ajustar_cupo(uuid,int,int,text), baja_responsable(uuid,int), listar_solicitudes(uuid),
  resolver_solicitud(uuid,int,boolean,int,text), guardar_config(uuid,jsonb), registrar_pago(uuid,int,int,text,text,boolean),
  verificar_pago(uuid,int,boolean,boolean), anular_pago(uuid,int), confirmar_invitados(uuid,int[]), liberar_vencidos(uuid),
  asignar_mesa(uuid,int[],int), guardar_mesa(uuid,jsonb), eliminar_mesa(uuid,int), registrar_pago_brindis(uuid,int,boolean,int,text),
  asignar_pulseras_auto(uuid), listar_usuarios(uuid), guardar_usuario(uuid,jsonb), ver_auditoria(uuid,int), backup_completo(uuid),
  checkin_buscar(uuid,text), checkin_registrar(uuid,int), checkin_deshacer(uuid,int), brindis_buscar(uuid,text),
  brindis_registrar(uuid,int), checkin_lista(uuid)
to anon, authenticated;
