// =====================================================================
//  CONFIGURACIÓN — completar con los datos de tu proyecto Supabase
//  (Supabase > Project Settings > API)
// =====================================================================
window.APP_CONFIG = {
  SUPABASE_URL: 'https://TU-PROYECTO.supabase.co',
  // "anon public" key (o "publishable key"). Es pública por diseño:
  // la seguridad está en las funciones de la base, no en esta clave.
  SUPABASE_ANON_KEY: 'PEGAR-ACA-LA-ANON-KEY',
  // Identidad visual (aparece en el ingreso y en las entradas)
  BRAND: { promo: 'Promo KAOS', lema: 'Una última noche, mil recuerdos' }
};
